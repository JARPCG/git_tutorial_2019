/* 
Problem 1:
Using Math, generate a random number between 0/1 and 1000 and display a whole number in the console using console.log
*/
