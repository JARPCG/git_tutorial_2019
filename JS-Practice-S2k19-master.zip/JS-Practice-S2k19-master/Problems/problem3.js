/*
Problem 3:
Using a for X in/of Y loop, iterate through the following array of objects and console.log the country name and abbreviation for each object.
*/
