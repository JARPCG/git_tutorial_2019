# JS-Practice-S2k19
Instructions:
- Create a fork of this repo.
- Clone your fork to your local machine.
- Make a new folder named [YourFistName-YourLastInitial].
- Copy the 3 problem files into your new folder and begin working.
- When you're done with your first 3 problems, push your changes to your local repo and then open a pull request here!
